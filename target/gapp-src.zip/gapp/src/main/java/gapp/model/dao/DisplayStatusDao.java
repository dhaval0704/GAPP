package gapp.model.dao;

import gapp.model.DisplayStatus;
import java.util.List;

public interface DisplayStatusDao {
	
	List<DisplayStatus> getStatusList();

}
